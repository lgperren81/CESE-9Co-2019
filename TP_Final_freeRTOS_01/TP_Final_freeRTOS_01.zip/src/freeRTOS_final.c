/*============================================================================
 * Autor: Luciano Perren <lgperren@gmail.com>
 * TP Final RTOS 1
 * Date: 2019/20/08
 * Docentes: Franco Bucafusco y Sergio Renato De Jesús Melean
 * freeRTOS_final.c
 *===========================================================================*/

/*==================[inlcusiones]============================================*/

// Includes de FreeRTOS
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

// sAPI header
#include "sapi.h"
#include "../../TP_Final_freeRTOS_01/inc/ina219.h"
#include "../../TP_Final_freeRTOS_01/inc/FreeRTOSConfig.h"


/*==================[definiciones y macros]==================================*/

/*==================[definiciones de datos internos]=========================*/

// INA219 Address
INA219_address_t addr = INA219_ADDRESS_0; // If INA219 A0 y A1 pin is connected to GND

static QueueHandle_t i2cQueue;

/*==================[definiciones de datos externos]=========================*/

DEBUG_PRINT_ENABLE;

/*==================[declaraciones de funciones internas]====================*/

/*==================[declaraciones de funciones externas]====================*/

// Prototipo de funcion de la tarea
// Tarea que realiza la lectura de los registros del INA219, los convierte de "float" a "string"
// y los guarda en la estructura que será enviada a la cola
void task_read_measurement( void* taskParmPtr );
// Es la unica tarea que puede enviar mensajes por la UART
void task_show_values( void* taskParmPtr );

/* Define the strings that the tasks and interrupt will print out via the
gatekeeper. */
/* struct I2C_message {
	char firstMessage[29];
	char _shuntVoltage[6];
	char secondMessage[27];
	char _busVoltage[6];
	char thirdMessage[21];
	char _power[6];
	char fourthMessage[23];
	char _current[6];
} data_INA219_t; */

//struct I2C_message *ptrI2Cstruct;		// Define un puntero a la estructura I2C_message

//static const char *firstMessage[] = { "INA219 Shunt Voltage in mV:"};

/*==================[funcion principal]======================================*/

// FUNCION PRINCIPAL, PUNTO DE ENTRADA AL PROGRAMA LUEGO DE ENCENDIDO O RESET.
int main(void)
{
   // ---------- CONFIGURACIONES ------------------------------
   // Inicializar y configurar la plataforma
   boardConfig();

   // UART for debug messages
   debugPrintConfigUart( UART_USB, 115200 );
   debugPrintlnString( "Final RTOS 1" );
   // Its Alive
   gpioWrite( LED3, ON );

   // Se crea cola que contiene 8 punteros a la estructura I2C_message
   i2cQueue = xQueueCreate( 10, sizeof( char * ) );

   /* Check the queue was created successfully. */
   if( i2cQueue != NULL ) {
	   // Crear tareas en freeRTOS
       xTaskCreate(
          task_read_measurement,      		 // Funcion de la tarea a ejecutar
          (const char *)"readINA219",        // Nombre de la tarea como String amigable para el usuario
          configMINIMAL_STACK_SIZE*5,        // Cantidad de stack de la tarea
          0,                                 // Parametros de tarea
          tskIDLE_PRIORITY+2,                // Prioridad de la tarea
          0                                  // Puntero a la tarea creada en el sistema
       );
       xTaskCreate(
          task_show_values,      		     // Funcion de la tarea a ejecutar
          (const char *)"printUART",         // Nombre de la tarea como String amigable para el usuario
          configMINIMAL_STACK_SIZE*5,        // Cantidad de stack de la tarea
          0,                                 // Parametros de tarea
          tskIDLE_PRIORITY+1,                // Prioridad de la tarea
          0                                  // Puntero a la tarea creada en el sistema
       );

   // Iniciar scheduler
   vTaskStartScheduler();
   }
   // ---------- REPETIR POR SIEMPRE --------------------------
   while( TRUE ) {
      // Si cae en este while 1 significa que no pudo iniciar el scheduler
   }

   // NO DEBE LLEGAR NUNCA AQUI, debido a que a este programa se ejecuta
   // directamenteno sobre un microcontroladore y no es llamado por ningun
   // Sistema Operativo, como en el caso de un programa para PC.
   return 0;
}

/*==================[definiciones de funciones internas]=====================*/

/*==================[definiciones de funciones externas]=====================*/

// Implementacion de funcion de la tarea
void task_read_measurement( void* taskParmPtr )
{
   // ---------- CONFIGURACIONES ------------------------------
   int iIndexToString;
   iIndexToString = ( int ) taskParmPtr;

   float shuntVoltage, busVoltage, power, current;	// Variables donde se almacenan las lecturas del INA219
   // Variables donde se almacenan las lecturas del INA219 luego de ser convertidas a "string"
   char shVoltage[6];
   char bsVoltage[6];
   char pow[6];
   char curr[6];

   // Inicializar INA219
   uartWriteString( UART_USB, "Inicializando INA219...\r\n" );
   vTaskDelay( 5000 / portTICK_RATE_MS );

   bool_t status;
   status = ina219Init( addr );

   if( status == FALSE ){
	   uartWriteString( UART_USB, "INA219 no inicializado, verifique las conexiones:\r\n\r\n" );
	   uartWriteString( UART_USB, "Se detiene el programa.\r\n" );
	   // Envia la tarea al estado bloqueado durante 1 s (delay)
	   vTaskDelay( 1000 / portTICK_RATE_MS );
	   }
	   uartWriteString( UART_USB, "INA219 inicializado correctamente.\r\n\r\n" );
	   vTaskDelay( 2000 / portTICK_RATE_MS );

   // Tarea periodica cada 1000 ms
   portTickType xPeriodicity =  1000 / portTICK_RATE_MS;
   portTickType xLastWakeTime = xTaskGetTickCount();

   // ---------- REPETIR POR SIEMPRE --------------------------
   while(TRUE) {
      // Leo los registros del INA219 cada 1 segundo (funcion en INA219.h)
	  ina219Read();

      /* Para NO utilizar "printf" convierto de "float" a "string" y utilizo la función
       * "uartWriteString" de la SAPI */
      shuntVoltage = ina219ShowShuntVoltage();			// Shunt Voltage
      floatToString ( shuntVoltage, shVoltage, 3 );		// Convierto a string
      busVoltage = ina219ShowBusVoltage();				// Bus Voltage
      floatToString( busVoltage, bsVoltage, 3);			// Convierto a string
      power = ina219ShowPower();						// Power
      floatToString( power, pow, 3);					// Convierto a string
      current = ina219ShowCurrent();					// Current
      floatToString( current, curr, 3);					// Convierto a string

      //char *firstMessage[] = "INA219 shunt voltage in mV:\r\n";
      //data_INA219_t.firstMessage[29] = "INA219 shunt voltage in mV:\r\n";
      //data_INA219_t._shuntVoltage[6] = shVoltage;
      //data_INA219_t.secondMessage[27] = "INA219 bus voltage in mV:\r\n";
      //data_INA219_t._busVoltage[6] = bsVoltage;
      //data_INA219_t.thirdMessage[21] = "INA219 power in mW:\r\n";
      //data_INA219_t._power[6] = pow;
      //data_INA219_t.fourthMessage[23] = "INA219 current in mA:\r\n";
      //data_INA219_t._current[6] = curr;

      //uartWriteString( UART_USB, &ptrI2Cstruct);
      //uartWriteString( UART_USB, shVoltage);
      /*uartWriteString( UART_USB, "\r\n");
      uartWriteString( UART_USB, "INA219 bus voltage in mV:\r\n");
      uartWriteString( UART_USB, bsVoltage);
      uartWriteString( UART_USB, "\r\n");
      uartWriteString( UART_USB, "INA219 power in mW:\r\n");
      uartWriteString( UART_USB, pow);
      uartWriteString( UART_USB, "\r\n");
      uartWriteString( UART_USB, "INA219 current in mA:\r\n");
      uartWriteString( UART_USB, curr);
      uartWriteString( UART_USB, "\r\n"); */

      xQueueSend( i2cQueue, &shVoltage, 0 );
      // Envia la tarea al estado bloqueado durante xPeriodicity (delay periodico)
      vTaskDelayUntil( &xLastWakeTime, xPeriodicity );
   }
}

/* Esta tarea es la unica que puede enviar un mensaje por la UART */
void task_show_values( void* taskParmPtr ){
          char *shVoltage;
	while(TRUE) {
	      //char *shVoltage;
		  /* Wait for a message to arrive. */
	      xQueueReceive( i2cQueue, &shVoltage, portMAX_DELAY );
	      printf( "%s", shVoltage );
	      uartWriteString (UART_USB, shVoltage);
	      //uartWriteString( UART_USB, ptrI2Cstruct);
	      /* Now simply go back to wait for the next message. */
	}
}

/*==================[fin del archivo]========================================*/
